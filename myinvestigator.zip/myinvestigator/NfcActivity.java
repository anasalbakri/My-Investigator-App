package com.example.cicino.myinvestigator;

import android.app.AlertDialog;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigInteger;


public class NfcActivity extends AppCompatActivity {

    private TextView result;
    private NfcAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfc);

        result = (TextView) findViewById(R.id.textView_explanation);
        adapter = NfcAdapter.getDefaultAdapter(this);

        if (adapter == null)
            result.setText("NFC is not supported on this device");
        else if (!adapter.isEnabled())
            result.setText("NFC is disabled.");
        else
            prepareNfc();







        final TextView tvName = (TextView) findViewById(R.id.tvName);
        final TextView tvCrimes = (TextView) findViewById(R.id.tvCrimes);


        final Button bIDSearch = (Button) findViewById(R.id.bIDSearch);




                final String ID = result.getText().toString();










        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms

                // Response received from the server
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            if (success) {
                                String name = jsonResponse.getString("name");
                                String crime1 = jsonResponse.getString("crime1");
                                String crime2 = jsonResponse.getString("crime2");
                                String crime3 = jsonResponse.getString("crime3");
                                String date1 = jsonResponse.getString("date1");
                                String date2 = jsonResponse.getString("date2");
                                String date3 = jsonResponse.getString("date3");



                                // Display user details
                                if (date2 == "null" && date3 == "null") {
                                    String message1 = "Crimes committed:-" + System.lineSeparator() +  System.lineSeparator()
                                            + crime1 + "           " + date1 + System.lineSeparator();
                                    tvCrimes.setText(message1);
                                }
                                else if (date3 == "null" && date2 != "null") {
                                    String message1 = "Crimes committed:-" + System.lineSeparator() +  System.lineSeparator()
                                            + crime1 + "           " + date1 + System.lineSeparator() + crime2 +
                                            "           " + date2 + System.lineSeparator();
                                    tvCrimes.setText(message1);
                                }
                                else {
                                    String message1 = "Crimes committed:-" + System.lineSeparator() + System.lineSeparator()
                                            + crime1 + "           " + date1 + System.lineSeparator() + crime2 +
                                            "           " + date2 + System.lineSeparator() + crime3 + "           " + date3;
                                    tvCrimes.setText(message1);
                                }


                                String message2 = "Name: " + name;

                                tvName.setText(message2);


                            } else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(NfcActivity.this);
                                builder.setMessage("Not Found")
                                        .setNegativeButton("Retry", null)
                                        .create()
                                        .show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };


                NfcRequest nfcRequest = new NfcRequest(ID, responseListener);
                RequestQueue queuel = Volley.newRequestQueue(NfcActivity.this);
                queuel.add(nfcRequest);
            }
        }, 5000);






    }




    private void prepareNfc() {

        result.setText("Prepare to Scan...");

        adapter.enableReaderMode(
                this,
                x -> {
                    //read value
                    byte[] id = x.getId();
                    //format as a positive number
                    String numberFormat = "%0" + (id.length * 2) + "X";
                    String text = String.format(numberFormat, new BigInteger(1, id));
                    //display the number
                    result.post(() -> result.setText(text));
                },





                NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
                new Bundle()
        );

    }



}
