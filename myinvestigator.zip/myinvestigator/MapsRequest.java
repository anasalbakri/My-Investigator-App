package com.example.cicino.myinvestigator;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class MapsRequest extends StringRequest {
    private static final String SEARCH_REQUEST_URL = "http://ajmanieee.esy.es/map.php";
    private Map<String, String> params;

    public MapsRequest(String stat, Response.Listener<String> listener) {
        super(Method.POST, SEARCH_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("static", stat);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
