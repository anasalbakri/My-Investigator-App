package com.example.cicino.myinvestigator;

import android.app.AlertDialog;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * A styled map using JSON styles from a raw resource.
 */
public class MapsActivity extends AppCompatActivity
        implements OnMapReadyCallback {


    private GoogleMap mMap;

    private static final String TAG = MapsActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Retrieve the content view that renders the map.
        setContentView(R.layout.activity_maps);

        // Get the SupportMapFragment and register for the callback
        // when the map is ready for use.
        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);










    }

    /**
     * Manipulates the map when it's available.
     * The API invokes this callback when the map is ready for use.
     */
    @Override
    public void onMapReady(final GoogleMap googleMap) {




        final String stat = "anas";



        // Response received from the server
        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");

                    if (success) {

                        int n = jsonResponse.getInt("nu");
                        String[] lat =new String[n];
                        String[] lng = new String[n];
                        String[] location = new String[n];


                        String la="lat";
                        String ln="lng";
                        String locatio="location";

                        String s = "0";
                        double[] dlat = new double[n];
                        double[] dlng = new double[n];
                        LatLng[] dlatlng = new LatLng[n];

                        LatLng uae = new LatLng(25.197641899999994,55.27870999999999);

                        for( int i=0 ; i<location.length ; i++) {
                            s = String.valueOf(i);
                            lat[i] = jsonResponse.getString(la+s);
                            lng[i] = jsonResponse.getString(ln+s);
                            location[i] = jsonResponse.getString(locatio+s);
                            dlat[i] = Double.parseDouble(lat[i]);
                            dlng[i] = Double.parseDouble(lng[i]);

                            dlatlng[i] = new LatLng(dlat[i],dlng[i]);

                            mMap = googleMap;

                            mMap.addMarker(new MarkerOptions().position(dlatlng[i]).title(location[i]).snippet(""));

                            CameraUpdate cameraPosition = CameraUpdateFactory.newLatLngZoom(uae, 7);
                            mMap.moveCamera(cameraPosition);
                            mMap.animateCamera(cameraPosition);


                        }


















                        try {
                            // Customise the styling of the base map using a JSON object defined
                            // in a raw resource file.
                            boolean succes = googleMap.setMapStyle(
                                    MapStyleOptions.loadRawResourceStyle(
                                            MapsActivity.this, R.raw.style_json));

                            if (!succes) {
                                Log.e(TAG, "Style parsing failed.");
                            }
                        } catch (Resources.NotFoundException e) {
                            Log.e(TAG, "Can't find style. Error: ", e);
                        }



                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
                        builder.setMessage("Not Found")
                                .setNegativeButton("Retry", null)
                                .create()
                                .show();
                    }







                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };


        MapsRequest mapsRequest = new MapsRequest(stat, responseListener);
        RequestQueue queuel = Volley.newRequestQueue(MapsActivity.this);
        queuel.add(mapsRequest);



    }
}
