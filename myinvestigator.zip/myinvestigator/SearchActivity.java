package com.example.cicino.myinvestigator;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class SearchActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        final EditText etsuspect = (EditText) findViewById(R.id.etRef);
        final TextView tvsuspect = (TextView) findViewById(R.id.tvsuspect);
        final Button button = (Button) findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String suspect = etsuspect.getText().toString();


                // Response received from the server
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            if (success) {
                                String suspect = jsonResponse.getString("suspect");
                                String victim = jsonResponse.getString("victim");
                                String crimedate = jsonResponse.getString("crimedate");
                                String crimetime = jsonResponse.getString("crimetime");



                                // Display user details
                                String message = "At :  " + crimetime + " " + suspect + " did a crime  " ;
                                tvsuspect.setText(message);

                            } else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(SearchActivity.this);
                                builder.setMessage("Not Found")
                                        .setNegativeButton("Retry", null)
                                        .create()
                                        .show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                SearchRequest searchRequest = new SearchRequest(suspect, responseListener);
                RequestQueue queue = Volley.newRequestQueue(SearchActivity.this);
                queue.add(searchRequest);
            }
        });
    }
}
