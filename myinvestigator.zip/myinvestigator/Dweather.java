package com.example.cicino.myinvestigator;

/**
 * Created by Anas on 05/04/2017.
 */

public class Dweather {
    public int icon;
    public String title;
    public Dweather(){
        super();
    }

    public Dweather(int icon, String title) {
        super();
        this.icon = icon;
        this.title = title;
    }
}