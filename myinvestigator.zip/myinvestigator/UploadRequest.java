package com.example.cicino.myinvestigator;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;



public class UploadRequest extends StringRequest {
    private static final String REGISTER_REQUEST_URL = "http://ajmanieee.esy.es/Upload.php";
    private Map<String, String> params;

    public UploadRequest(String crimedate, String crimetime, String upldate, String location, String victim, String suspect, String evidence, String lat, String lng, String Crimetype, Response.Listener<String> listener) {
        super(Method.POST, REGISTER_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("crimedate", crimedate);
        params.put("crimetime", crimetime);
        params.put("upldate", upldate);
        params.put("location", location);
        params.put("victim", victim);
        params.put("suspect", suspect);
        params.put("evidence", evidence);
        params.put("lat", lat);
        params.put("lng", lng);
        params.put("crimetype", Crimetype);

    }
    @Override
    public Map<String, String> getParams() {
        return params;

    }



}