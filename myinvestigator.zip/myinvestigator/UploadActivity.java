package com.example.cicino.myinvestigator;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import android.widget.AdapterView.OnItemSelectedListener;

import static com.example.cicino.myinvestigator.R.id.activity_upload;
import static com.example.cicino.myinvestigator.R.id.crimetype;


public class UploadActivity extends AppCompatActivity implements OnItemSelectedListener{

    private static TextView tvDate, tvTime;
    private static final int Date_id = 0;
    private static final int Time_id = 1;
    public String Crimetype="";

    TextView placeNameText;
    TextView placeAddressText;
    TextView placeLatText;
    TextView placeLngText;
    Button getPlaceButton;
    private final static int MY_PERMISSION_FINE_LOCATION = 101;
    private final static int PLACE_PICKER_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        requestPermission();

        placeNameText = (TextView) findViewById(R.id.tvPlaceName);
        placeAddressText = (TextView) findViewById(R.id.tvPlaceAddress);
        placeLatText = (TextView) findViewById(R.id.tvPlaceLat);
        placeLngText = (TextView) findViewById(R.id.tvPlaceLng);

        getPlaceButton = (Button) findViewById(R.id.btGetPlace);
        getPlaceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                try {
                    Intent intent = builder.build(UploadActivity.this);
                    startActivityForResult(intent, PLACE_PICKER_REQUEST);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }

            }
        });


        final Button bDate = (Button) findViewById(R.id.bDate);
        final Button bTime = (Button) findViewById(R.id.bTime);
        tvDate = (TextView) findViewById(R.id.tvDate);
        tvTime = (TextView) findViewById(R.id.tvTime);

        bDate.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                // Show Date dialog
                showDialog(Date_id);
            }
        });
        bTime.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                // Show bTime dialog
                showDialog(Time_id);
            }
        });




        final EditText etvictim = (EditText) findViewById(R.id.etvictim);
        final Calendar cal = Calendar.getInstance();
        final SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        final String upload = format1.format(cal.getInstance().getTime());
        final EditText etsuspect = (EditText) findViewById(R.id.etRef);
        final EditText etevidence = (EditText) findViewById(R.id.etevidence);
        final Button bUpload = (Button) findViewById(R.id.bUpload);

        Spinner spinner = (Spinner) findViewById(R.id.crimetype);
        spinner.setOnItemSelectedListener(this);



// Create an ArrayAdapter using the string array and a default spinner layout
        //ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
          //      R.array.planets_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        //spinner.setAdapter(adapter);
        // Spinner element

        // Spinner click listener

        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("Automobile");
        categories.add("Business Services");
        categories.add("Computers");
        categories.add("Education");
        categories.add("Personal");
        categories.add("Travel");

        String[] items = new String[]{"Murder","Robbery","Burglary","Stalking & Harrasement","Violent crime","Antisocial behavior","Children abuse","Crime abroad","Cyber crime","Domestic abuse","Rape","Sexual Assault","Sexual Harrasement","Hate crime", "Alcohol related" , "Drugs"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        spinner.setAdapter(adapter);

//        @Override
//        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//            // On selecting a spinner item
//            String item = parent.getItemAtPosition(position).toString();
//
//            // Showing selected spinner item
//            Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
//        }





        // Creating adapter for spinner
        //ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        //dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        //spinner.setAdapter(dataAdapter);

        bUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final String crimedate = tvDate.getText().toString();
                final String crimetime = tvTime.getText().toString();
                final String location = placeNameText.getText().toString();
                final String upldate = upload;
                final String victim = etvictim.getText().toString();
                final String suspect = etsuspect.getText().toString();
                final String evidence = etevidence.getText().toString();
                final String lat = placeLatText.getText().toString();
                final String lng = placeLngText.getText().toString();







                if(crimedate.equals(""))
                {
                    Toast t =Toast.makeText(UploadActivity.this, "Please enter the crime date", Toast.LENGTH_SHORT);
                    t.show();
                }

                if(crimetime.equals(""))
                {
                    Toast t =Toast.makeText(UploadActivity.this, "Please enter the crime time", Toast.LENGTH_SHORT);
                    t.show();
                }
                if(location.equals(""))
                {
                    Toast t =Toast.makeText(UploadActivity.this, "Please enter the crime location", Toast.LENGTH_SHORT);
                    t.show();
                }
                if(Crimetype.equals(""))
                {
                    Toast t =Toast.makeText(UploadActivity.this, "Please enter the crime type", Toast.LENGTH_SHORT);
                    t.show();
                }

                else {
                    Response.Listener<String> responselistener = new Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONObject jsonResponse = new JSONObject(response);
                                boolean success = jsonResponse.getBoolean("success");


                                if (success) {

                                    Intent intent = new Intent(UploadActivity.this, Detector.class);
                                    intent.putExtra("evidence", evidence);
                                    UploadActivity.this.startActivity(intent);
                                } else {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(UploadActivity.this);
                                    builder.setMessage("Upload Failed")
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }



                        }
                    };

                    UploadRequest uploadRequest = new UploadRequest(crimedate, crimetime, upldate, location, victim, suspect, evidence, lat, lng, Crimetype, responselistener);
                    RequestQueue queue = Volley.newRequestQueue(UploadActivity.this);
                    queue.add(uploadRequest);
                }


            }
        });


    }


    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();


        // Showing selected spinner item


        Crimetype=item;
    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    private void requestPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSION_FINE_LOCATION);
            }
        }
    }




    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case MY_PERMISSION_FINE_LOCATION:
                if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "This app requires location permissions to be granted", Toast.LENGTH_LONG).show();
                    finish();
                }
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PLACE_PICKER_REQUEST){
            if (resultCode == RESULT_OK){
                Place place = PlacePicker.getPlace(UploadActivity.this, data);
                placeNameText.setText(place.getName());
                placeAddressText.setText(place.getAddress());

                final LatLng localtionlatlng = place.getLatLng();

                double lati = localtionlatlng.latitude;
                double lngi = localtionlatlng.longitude;



                String slat = String.valueOf(lati);
                String slng = String.valueOf(lngi);



                String latlngstring = localtionlatlng.toString();

                placeLatText.setText(slat);
                placeLngText.setText(slng);


            }
        }
    }



    protected Dialog onCreateDialog(int id) {

        // Get the calander
        Calendar c = Calendar.getInstance();

        // From calander get the year, month, day, hour, minute
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        switch (id) {
            case Date_id:

                // Open the datepicker dialog
                return new DatePickerDialog(UploadActivity.this, date_listener, year,
                        month, day);
            case Time_id:

                // Open the timepicker dialog
                return new TimePickerDialog(UploadActivity.this, time_listener, hour,
                        minute, false);

        }
        return null;
    }

    // Date picker dialog
    DatePickerDialog.OnDateSetListener date_listener = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int month, int day) {
            // store the data in one string and set it to text
            String date1 = String.valueOf(year) + "-" + String.valueOf(month+1)
                    + "-" + String.valueOf(day); //check this code next month
            tvDate.setText(date1);
        }
    };
    TimePickerDialog.OnTimeSetListener time_listener = new TimePickerDialog.OnTimeSetListener() {

        @Override
        public void onTimeSet(TimePicker view, int hour, int minute) {
            // store the data in one string and set it to text
            String time1 = String.format("%02d:%02d", hour, minute);
            tvTime.setText(time1);
        }
    };




}
