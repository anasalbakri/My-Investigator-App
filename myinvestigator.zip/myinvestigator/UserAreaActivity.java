package com.example.cicino.myinvestigator;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class UserAreaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_area);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String username = intent.getStringExtra("username");


        TextView tvWelcomeMsg = (TextView) findViewById(R.id.tvWelcomeMsg);
        EditText etUsername = (EditText) findViewById(R.id.etUsername);


        // Display user details
        String message =" welcome, " + name;
        tvWelcomeMsg.setText(message);
        etUsername.setText(username);

        final Button bUpload = (Button) findViewById(R.id.bUpload);
        final Button bSearch = (Button) findViewById(R.id.bSearch);
        final Button bNFC = (Button) findViewById(R.id.bNFC);

        final Button bMap = (Button) findViewById(R.id.bMap);

        bUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(UserAreaActivity.this, UploadActivity.class);
                UserAreaActivity.this.startActivity(intent);
            }

        });

        bSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(UserAreaActivity.this, SearchActivity.class);
                UserAreaActivity.this.startActivity(intent);
            }

        });


        bNFC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(UserAreaActivity.this, NfcActivity.class);
                UserAreaActivity.this.startActivity(intent);
            }

        });



        bMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(UserAreaActivity.this, MapsActivity.class);
                UserAreaActivity.this.startActivity(intent);
            }

        });


    }





}

