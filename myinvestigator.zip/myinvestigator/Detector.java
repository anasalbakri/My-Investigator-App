package com.example.cicino.myinvestigator;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Detector extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detector);

        Intent intent = getIntent();
        String evidence = intent.getStringExtra("evidence");

        final Button button = (Button) findViewById(R.id.bSignIn);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Detector.this, UserAreaActivity.class);
                Detector.this.startActivity(intent1);
            }
        });






        final ListView listView1 = (ListView) findViewById(R.id.abcde);
        //Intent intent = new Intent(Detector.this, UserAreaActivity.class);
        //Detector.this.startActivity(intent);


        //final TextView tv = (TextView) findViewById(R.id.tvresult);



        if(evidence.equals(""))
        {
            Toast t =Toast.makeText(Detector.this, "You haven't entered any evidence ", Toast.LENGTH_SHORT);
            t.show();
        }
        else {

            // Response received from the server
            Response.Listener<String> responseListener = response -> {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");


                    if (success) {
                        int n = jsonResponse.getInt("nu");


                        if (n == 1) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(Detector.this);
                            builder.setMessage("No similiar evidence for this case.")
                                    .setNegativeButton("OK", null)
                                    .create()
                                    .show();
                            ;


                        } else if (n > 1) {

                            String[] evidences = new String[n];
                            String[] suspect = new String[n];
                            String[] victim = new String[n];
                            String[] crimedate = new String[n];
                            String[] crimetime = new String[n];
                            //String[] crimetype = new String[n];
                            String[] location = new String[n];


                            String evidenc = "evidence";
                            String suspec = "suspect";
                            String victi = "victim";
                            String crimedat = "crimedate";
                            String crimetim = "crimetime";
                            //String crimetyp = "crimetype";
                            String locatio = "location";


                            String s = "0";
                            evidences[0] = jsonResponse.getString(evidenc + s);


                            Dweather weather_data[] = new Dweather[n];

                            for (int i = 0; i < evidences.length; i++) {
                                s = String.valueOf(i);
                                evidences[i] = jsonResponse.getString(evidenc + s);
                                suspect[i] = jsonResponse.getString(suspec + s);
                                victim[i] = jsonResponse.getString(victi + s);
                                crimedate[i] = jsonResponse.getString(crimedat + s);
                                crimetime[i] = jsonResponse.getString(crimetim + s);
                                //crimetype[i] = jsonResponse.getString(crimetyp+s);
                                location[i] = jsonResponse.getString(locatio + s);


                                weather_data[i] = new Dweather(R.drawable.barcode2, "A crime with similar evidence: " + evidences[i] + " has happened against " + victim[i] + " On " + crimedate[i] + " at " + crimetime[i] + " in " + location[i] + ". Expected criminal is: " + suspect[i]);

                                //String message = "Criminal  is: " + criminals[i] + String.valueOf(i)+  "    "  +  "   \n\n";
                                //tv.setText(message);

                            }


                            //Toast msg = Toast.makeText(getBaseContext(),criminals[0]+criminals[1]+criminals[2]+criminals.length,Toast.LENGTH_LONG);
                            //msg.show();
                            //Weather weather_data[] = new Weather[]{new Weather(R.drawable.barcode2, "Criminal: "+criminals[0]+" has committed "+crimeI[0]+" On "+dateI[0])};


                            DWeatherAdapter adapter = new DWeatherAdapter(Detector.this,
                                    R.layout.dlistview_item_row, weather_data);

                            //ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                            //      android.R.layout.activity_list_item,android.R.id.text1, criminals);
                            //View header = (View)getLayoutInflater().inflate(R.layout.listview_header_row, null);
                            //listView1.addHeaderView(header);

                            listView1.setAdapter(adapter);

                            // user details


                            //int listSize = names.size();

                            //for (int i = 0; i<listSize; i++){
                            //  Log.i("criminals name: ", names.get(i));
                            //}


                        }
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Detector.this);
                        builder.setMessage("Search failed. Network Error")
                                .setNegativeButton("Retry", null)
                                .create()
                                .show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            };

            DetectorRequest detectorRequst = new DetectorRequest(evidence, responseListener);
            RequestQueue queue = Volley.newRequestQueue(Detector.this);
            queue.add(detectorRequst);
        }


    }
}



